import scala.io.Source

object EnvLoader {
  def loadEnv(filePath: String = ".env"): Unit = {
    val source = Source.fromFile(filePath)
    source.getLines()
      .filter(line => line.contains("=") && !line.startsWith("#"))
      .foreach { line =>
        val Array(key, value) = line.split("=", 2)
        sys.props.put(key.trim, value.trim)
      }
    source.close()
  }

  def getEnv(key: String, default: String = ""): String = {
    sys.props.getOrElse(key, default)
  }
}
