import org.apache.spark.sql.SparkSession
import org.mongodb.spark.MongoSpark
import org.mongodb.spark.config.WriteConfig
import java.io.File

object NistJsonToMongo {

  def main(args: Array[String]): Unit = {
    // Charger les variables d'environnement
    EnvLoader.loadEnv()

    // Récupérer les valeurs du fichier .env
    val mongoUri = EnvLoader.getEnv("MONGO_URI")
    val mongoDatabase = EnvLoader.getEnv("MONGO_DATABASE")
    val mongoCollection = EnvLoader.getEnv("MONGO_COLLECTION")

    // Initialisation de Spark
    val spark = SparkSession.builder()
      .appName("Nist JSON to MongoDB")
      .master("local[*]")
      .config("spark.mongodb.write.connection.uri", mongoUri)
      .config("spark.mongodb.read.connection.uri", mongoUri)
      .getOrCreate()

    import spark.implicits._

    // Chemin vers le dossier contenant les fichiers JSON
    val dataDir = "data"

    // Récupérer tous les fichiers JSON du dossier
    val jsonFiles = new File(dataDir).listFiles.filter(_.getName.endsWith(".json"))

    // Charger et combiner tous les fichiers JSON dans un DataFrame
    val rawDf = jsonFiles.map(file => spark.read.json(file.getAbsolutePath)).reduce(_ union _)

    // Filtrer les CVEs de 2024 et 2023
    val cveDf = rawDf
      .selectExpr(
        "cve.CVE_data_meta.ID as ID",
        "cve.description.description_data[0].value as Description",
        "impact.baseMetricV3.cvssV3.baseScore as baseScore",
        "impact.baseMetricV3.cvssV3.baseSeverity as baseSeverity",
        "impact.baseMetricV3.exploitabilityScore as exploitabilityScore",
        "impact.baseMetricV3.impactScore as impactScore"
      )
      .filter($"ID".rlike("^CVE-(2023|2024)"))

    // Enregistrer dans MongoDB
    val writeConfig = WriteConfig(Map(
      "uri" -> mongoUri,
      "database" -> mongoDatabase,
      "collection" -> mongoCollection
    ))

    MongoSpark.save(cveDf.write
      .mode("overwrite")
      .format("mongo")
      .options(writeConfig.asOptions)
    )

    println(s"Les données ont été enregistrées dans la collection MongoDB '$mongoCollection'.")

    // Charger les données depuis MongoDB
    val mongoDf = spark.read
      .format("mongo")
      .option("uri", mongoUri)
      .option("database", mongoDatabase)
      .option("collection", mongoCollection)
      .load()

    // Exécuter les requêtes Spark SQL
    mongoDf.createOrReplaceTempView("cve")

    // Top 5 impactScore pour 2024
    val top2024Df = spark.sql(
      "SELECT ID, Description, impactScore FROM cve WHERE ID LIKE 'CVE-2024%' ORDER BY impactScore DESC LIMIT 5"
    )
    println("Top 5 des impactScores pour 2024 :")
    top2024Df.show()

    // Top 5 impactScore pour 2023
    val top2023Df = spark.sql(
      "SELECT ID, Description, impactScore FROM cve WHERE ID LIKE 'CVE-2023%' ORDER BY impactScore DESC LIMIT 5"
    )
    println("Top 5 des impactScores pour 2023 :")
    top2023Df.show()

    // Top 5 impactScore et baseSeverity = 'MEDIUM' pour 2024
    val medium2024Df = spark.sql(
      "SELECT ID, Description, impactScore FROM cve WHERE ID LIKE 'CVE-2024%' AND baseSeverity = 'MEDIUM' ORDER BY impactScore DESC LIMIT 5"
    )
    println("Top 5 des impactScores avec baseSeverity = 'MEDIUM' pour 2024 :")
    medium2024Df.show()

    // Top 5 impactScore et baseSeverity = 'MEDIUM' pour 2023
    val medium2023Df = spark.sql(
      "SELECT ID, Description, impactScore FROM cve WHERE ID LIKE 'CVE-2023%' AND baseSeverity = 'MEDIUM' ORDER BY impactScore DESC LIMIT 5"
    )
    println("Top 5 des impactScores avec baseSeverity = 'MEDIUM' pour 2023 :")
    medium2023Df.show()

    spark.stop()
  }
}
