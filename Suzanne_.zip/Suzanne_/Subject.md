# FP Project

Read the NIST JSON feed.  
Write it into Atlas  
Make sure you store files less than 512 MB (Take only 2024, 2023)  

```
"ID" : "CVE-2024-9657",
"Description: "The Element Pack Elementor Addons (Header Footer, Template Library, Dynamic Grid & Carousel, Remote Arrows) plugin for WordPress is vulnerable to Stored Cross-Site Scripting via the ‘tooltip' parameter in all versions up to, and including, 5.10.2 due to insufficient input sanitization and output escaping. This makes it possible for authenticated attackers, with Contributor-level access and above, to inject arbitrary web scripts in pages that will execute whenever a user accesses an injected page."
"baseScore" : 6.5,
"baseSeverity" : "MEDIUM"
"exploitabilityScore" : 2.8,
"impactScore" : 3.6
```

## Tasks
- Finally, bring this data in Spark from MongoDB and run running Spark SQL and show top 5 impact score in 2024  
- Finally, bring this data in Spark from MongoDB by run Spark SQL and show top 5 impact score in 2023
- Finally, bring this data in Spark from MongoDB by run Spark SQL and show top 5 impact score and "baseSeverity" : "MEDIUM" in 2024
- Finally, bring this data in Spark from MongoDB by run Spark SQL and show top 5 impact score and "baseSeverity" : "MEDIUM" in 2023